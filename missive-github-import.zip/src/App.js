
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import MessageCreator from './components/MessageCreator';
import Constellations from './components/Constellations';

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/create-message" element={<MessageCreator />} />
                <Route path="/constellations" element={<Constellations />} />
            </Routes>
        </Router>
    );
}

export default App;
