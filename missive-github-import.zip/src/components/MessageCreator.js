
import React, { useState } from 'react';

function MessageCreator() {
    const [message, setMessage] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Message submitted:', message);
    };

    return (
        <div>
            <h1>Create a Message</h1>
            <form onSubmit={handleSubmit}>
                <textarea
                    placeholder="Write your message here..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                />
                <button type="submit">Send</button>
            </form>
        </div>
    );
}

export default MessageCreator;
