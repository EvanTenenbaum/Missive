
import React from 'react';

function Dashboard() {
    return (
        <div>
            <h1>Dashboard</h1>
            <p>Welcome to the Missive Web App!</p>
        </div>
    );
}

export default Dashboard;
