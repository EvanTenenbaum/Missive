
import React from 'react';

function Constellations() {
    return (
        <div>
            <h1>Constellations</h1>
            <p>Manage your groups here.</p>
        </div>
    );
}

export default Constellations;
